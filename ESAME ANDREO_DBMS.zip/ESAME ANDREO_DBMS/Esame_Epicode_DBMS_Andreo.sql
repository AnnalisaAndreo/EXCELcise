-- CREO IL DATABASE
create database if not exists Esame_Epicode_DBMS_ANDREO;
use Esame_Epicode_DBMS_ANDREO;


-- CREO LE TABELLE PRODUCT, REGION, SALES, VENDITA

create table product_prodotto (
    id_product int auto_increment primary key,
    nome_prodotto varchar(255),
    prezzo_unitario decimal(10, 2),
    categoria varchar(255)
);


create table region (
    id_region int auto_increment primary key,
    nome_area varchar(255),
    regione varchar(255)
);


create table sales (
    id_fattura int auto_increment primary key,
    fk_id_region int,
    fk_id_product int,
    prezzo_unitario decimal(10,2),
    data_acquisto date,
    numero_pezzi int,
    importo_totale decimal(10,2),
    cliente varchar(255),
    indirizzo varchar(255),
    citta varchar(255),
    foreign key (fk_id_region) references region(id_region),
    foreign key (fk_id_product) references product_prodotto(id_product)
);

create table vendita (
    id_transazione int auto_increment primary key,
    fk_id_fattura int,
    metodo_pagamento varchar(255),
    data_pagamento date,
    foreign key (fk_id_fattura) references sales(id_fattura)
);

insert into product_prodotto (nome_prodotto, prezzo_unitario, categoria) values
('Set Costruzioni 1', 22.00, 'Costruzioni'),
('Set Costruzioni 2', 20.00, 'Costruzioni'),
('Puzzle 1', 15.00, 'Puzzle'),
('Puzzle 2', 17.00, 'Puzzle'),
('Carte napoletane', 5.00, 'Carte da Gioco'),
('Carte UNO', 8.00, 'Carte da Gioco'),
('Monopoli', 30.00, 'Giochi da Tavolo'),
('Risiko', 35.00, 'Giochi da Tavolo'),
('Forza 4', 20.00, 'Giochi da Tavolo'),
('Taboo', 25.00, 'Giochi da Tavolo');

select*from product_prodotto;

insert into region (nome_area, regione) values 
('Lombardia', 'Italia Nord-Ovest'), 
('Liguria', 'Italia Nord-Ovest'), 
('Piemonte', 'Italia Nord-Ovest'),
('Puglia', 'Italia Centro-Sud'), 
('Campania', 'Italia Centro-Sud');

select* from region;

insert into sales (fk_id_region, fk_id_product, prezzo_unitario, data_acquisto, numero_pezzi, importo_totale, cliente, indirizzo, citta) values
(1, 1, 22.00, '2023-05-01', 2, 44.00, 'Cliente 1', 'Via Milano 1', 'Milano'),
(1, 1, 22.00, '2023-05-12', 1, 22.00, 'Cliente 11', 'Via Milano 11', 'Milano'),
(2, 2, 20.00, '2023-05-02', 3, 60.00, 'Cliente 2', 'Via Torino 1', 'Torino'),
(2, 2, 20.00, '2023-05-13', 2, 40.00, 'Cliente 12', 'Via Torino 2', 'Torino'),
(3, 3, 15.00, '2023-05-03', 1, 15.00, 'Cliente 3', 'Via Genova 1', 'Genova'),
(3, 3, 15.00, '2023-05-14', 2, 30.00, 'Cliente 13', 'Via Genova 2', 'Genova'),
(4, 4, 17.00, '2023-05-04', 1, 17.00, 'Cliente 4', 'Via Bari 1', 'Bari');

select*from sales;

insert into vendita (fk_id_fattura, metodo_pagamento, data_pagamento) values
(1, 'Carta di credito', '2023-05-02'),
(2, 'Carta di credito', '2023-05-03'),
(3, 'Carta di credito', '2023-05-04'),
(4, 'Carta di Credito', '2023-05-05'),
(5, 'Contanti', '2023-05-06'),
(6, 'Contanti', '2023-05-07'),
(7, 'Contanti', '2023-05-08');

rename table vendita to transazione_vendita;
select* from transazione_vendita;

-- RICHIESTA_1: Verificare che i campi definiti come PK siano univoci. 
-- RISPOSTA: aver scelto una chiave primaria nelle tabelle implica automaticamente che i valori in quella colonna siano univoci.

-- ad ogni modo potremmo fare una verifica dei duplicati con questa formula:
-- CONTIAMO il numero di righe in cui il valore ID è presente
-- raggruppiamo in funzione di un criterio specifico con GROUP BY + HAVING 
-- in caso di assenza di duplicati non ci verrà restituito alcun valore

SELECT id_product, COUNT(*) as duplicati
FROM product_prodotto
GROUP BY id_product
HAVING COUNT(*) > 1;

SELECT id_region, COUNT(*) as duplicati
FROM region
GROUP BY id_region
HAVING COUNT(*) > 1;

SELECT id_fattura, COUNT(*) as duplicati
FROM sales
GROUP BY id_fattura
HAVING COUNT(*) > 1;

SELECT id_transazione, COUNT(*) as duplicati
FROM transazione_vendita
GROUP BY id_transazione
HAVING COUNT(*) > 1;


-- RICHIESTA_2: Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    p.nome_prodotto,
    YEAR(s.data_acquisto) AS anno,
    SUM(s.importo_totale) AS fatturato_totale
FROM 
    sales s
JOIN 
    product_prodotto p ON s.fk_id_product = p.id_product
GROUP BY 
    p.nome_prodotto, YEAR(s.data_acquisto)
ORDER BY 
    p.nome_prodotto, anno;

-- RICHIESTA_3: Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
-- in questa simulazione stato è stato sostituito da regione 

-- mi sono resa conto di aver invertito l'inserimento dei valori nella colonna
ALTER TABLE region 
CHANGE nome_area regione VARCHAR(255),
CHANGE regione nome_area VARCHAR(255);

select * from region;

-- FATTURATO REGIONE E ANNO IN ORDINE DECRESCENTE 
SELECT 
    r.regione,
    YEAR(s.data_acquisto) AS anno,
    SUM(s.importo_totale) AS fatturato_totale
FROM 
    sales s
JOIN 
    region r ON s.fk_id_region = r.id_region
GROUP BY 
    anno, r.regione
ORDER BY 
    anno DESC, fatturato_totale DESC;

-- RICHIESTA_4: Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT 
    p.categoria,
    SUM(s.numero_pezzi) AS pezzi_venduti
FROM 
    sales s
JOIN 
    product_prodotto p ON s.fk_id_product = p.id_product
GROUP BY 
    p.categoria
ORDER BY 
    pezzi_venduti DESC
LIMIT 1;

-- RICHIESTA_5: Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

SELECT p.nome_prodotto AS invenduto
FROM product_prodotto p
LEFT JOIN sales s ON p.id_product = s.fk_id_product
WHERE s.fk_id_product IS NULL;

-- RICHIESTA_6: Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT 
    p.nome_prodotto,
    MAX(s.data_acquisto) AS ultima_data_vendita
FROM 
    product_prodotto p
JOIN 
    sales s ON p.id_product = s.fk_id_product
    GROUP BY 
    p.nome_prodotto
ORDER BY 
    ultima_data_vendita DESC;
